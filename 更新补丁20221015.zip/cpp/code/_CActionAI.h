#ifndef EASYMOD__CACTIONAI_H
#define EASYMOD__CACTIONAI_H

#define extends_CActionAssist \
bool aiCheckAttackable(int StartAreaID, int TargetAreaID, int ArmyIndex, int ArmyAreaID);
//bool NewCheckAttackAble(int StartAreaID, int TargetAreaID, int ArmyIndex,int ArmyAreaID);
#endif //EASYMOD__CACTIONAI_H
