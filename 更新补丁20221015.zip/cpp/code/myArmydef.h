//
// Created by KK on 2022/1/26.
//

#ifndef WC2_MYARMYDEF_H
#define WC2_MYARMYDEF_H

#endif //WC2_MYARMYDEF_H
struct CMyArmydef{

};