#ifndef _Included_com_easytech_wc2_TestActivity
#define _Included_com_easytech_wc2_TestActivity

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif
//事件定义 这些可以不搞
//JNIEXPORT void JNICALL Java_com_easytech_wc2_TestActivity_AnnexOfCountry(JNIEnv *, jobject, jstring, jint);
//JNIEXPORT void JNICALL Java_com_easytech_wc2_TestActivity_Event_1De1_1Choose1_1OccupyArea(JNIEnv *, jobject,jstring theAreaID,jstring targetAreaID, jint money,jint industry,jint oil,jint percent,jstring newCountryID,jstring newCountryName);
//JNIEXPORT void JNICALL Java_com_easytech_wc2_TestActivity_DiplomaticOfCountry(JNIEnv *, jclass, jstring);
//JNIEXPORT void JNICALL Java_com_easytech_wc2_TestActivity_Event_1De1_1Choose2_1OccupyArea(JNIEnv *env, jobject,jstring targetCountryID);


#ifdef __cplusplus
}
#endif
#endif
